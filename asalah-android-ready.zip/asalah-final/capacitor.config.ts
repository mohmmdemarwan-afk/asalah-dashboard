import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.asalah.furnishings',
  appName: 'مفروشات الأصالة',
  webDir: 'public',
  server: {
    url: 'https://asalah-final-v4-j4c7kptsw-mohmmdemarwan-5295.vercel.app',
    cleartext: false,
  },
};

export default config;
