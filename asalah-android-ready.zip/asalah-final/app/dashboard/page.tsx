import {createClient} from '@/lib/supabase/server'
import Dashboard from '@/components/Dashboard'
export default async function Page(){const supabase=await createClient();const {data:{user}}=await supabase.auth.getUser();if(!user)return null;return <Dashboard user={user.email||''}/>}
