# Asalah Android - Initial Native Shell

This version creates an Android Capacitor project through GitHub Actions.

- App ID: `com.asalah.furnishings`
- Node: 22
- Java: 21
- Capacitor: 8
- Supabase and Google OAuth settings are not changed.
- The current web URL remains configured in `capacitor.config.ts` for this first build.

This is an initial Android shell build, not yet a fully offline/local Next.js export.
