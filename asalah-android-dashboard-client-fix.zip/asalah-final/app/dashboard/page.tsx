'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import Dashboard from '@/components/Dashboard'

export default function Page() {
  const router = useRouter()
  const [email, setEmail] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const supabase = createClient()

    supabase.auth.getUser().then(({ data }) => {
      if (!data.user) {
        router.replace('/login')
        return
      }
      setEmail(data.user.email || '')
      setLoading(false)
    })
  }, [router])

  if (loading) return <main className="login"><div className="card">جاري تحميل لوحة التحكم...</div></main>
  if (email === null) return null

  return <Dashboard user={email} />
}
